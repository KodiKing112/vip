import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.optimus/?site=cFav&function=setBookmark)", True)
