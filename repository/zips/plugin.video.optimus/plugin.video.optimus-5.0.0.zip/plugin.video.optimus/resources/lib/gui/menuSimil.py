import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.optimus/?site=cGui&function=viewSimil)", True)
