        elif hasattr(e, 'code'):
            logger.error("Codigo de error HTTP : %d" % e.code)
            platformtools.dialog_ok(config.__addon_name, "El sitio web no funciona correctamente (error http %d)" % e.code)

    except WebErrorException, e:
        import traceback
        logger.error(traceback.format_exc())
        
        # Ofrecer buscar en otros canales o en el mismo canal, si está activado en la configuración
        if item.contentType in ['movie', 'tvshow', 'season', 'episode'] and config.get_setting('tracking_weberror_dialog', default=True):
            if item.action == 'findvideos': platformtools.play_fake()

            item_search = platformtools.dialogo_busquedas_por_fallo_web(item)
            if item_search is not None:
                platformtools.itemlist_update(item_search)
                
        else:
            platformtools.dialog_ok('Error en el canal ' + item.channel, 
                                    'La web de la que depende parece no estar disponible, puede volver a intentarlo, si el problema persiste verifique mediante un navegador la web: %s' % (e) )

    except:
        import traceback
        logger.error(traceback.format_exc())
        platformtools.dialog_ok(
            "Error inesperado en el canal " + item.channel,
            "Puede deberse a un fallo de conexión, la web del canal ha cambiado su estructura, o un error interno del addon. Para saber más detalles, consulta el log.")


logger.info('Ending with %s' % sys.argv[1])
