# -*- coding: utf-8 -*-
import re
import time

global global_var,stop_all#global
global_var=[]
stop_all=0
from  resources.modules.client import get_html
 
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
from  resources.modules import cache
try:
   from resources.modules.general import Addon,get_imdb
except:
  import Addon
type=['tv','torrent']

import urllib2,urllib,logging,base64,json
color=all_colors[110]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    if tv_movie=='movie':
        return []
    imdb_id=cache.get(get_imdb, 999,tv_movie,id,table='pages')
    seed=''
    f_seeds=False
    use_debrid=Addon.getSetting('debrid_use')=='true'

    # if (Addon.getSetting('torrents')=='true' and use_debrid==False):
    f_seeds=True
        # seed='S: >>'
    allow_debrid=True
    search_url=('%s-s%se%s'%(clean_name(original_title,1).replace(' ','-'),season_n,episode_n)).lower()
    for pages in range(0,3):
        x=get_html('https://eztv.re/api/get-torrents?imdb_id=%s&limit=100&page=%s'%(imdb_id.replace('tt',''),str(pages)),headers=base_header,timeout=10).json()
        
        max_size=int(Addon.getSetting("size_limit"))
        dev_num=1024*1024*1024
        for items in x['torrents']:
                    title=items['filename']
                   
                    if 's%se%s.'%(season_n,episode_n) not in title.lower():
                        continue
                    lk=items['magnet_url']
                    size=(float(items['size_bytes'])/dev_num)
                    
                    if f_seeds:
                       try:
                        seed=items['seeds']
                        if int(Addon.getSetting('min_seed'))>int(seed):
                            continue
                        # seed='S:%s>>,'%str(seed)
                       except:
                        continue
                    
                    if int(size)<max_size:
                       if '2160' in title:
                              res='2160'
                       if '1080' in title:
                              res='1080'
                       elif '720' in title:
                              res='720'
                       elif '480' in title:
                              res='480'
                       elif '360' in title:
                              res='360'
                       else:
                              res='HD'

                     
                      
                       # all_links.append((seed+title,lk,str(size),res))
                       try:
                        size=str(round(float(size), 2))
                       except:pass
                       all_links.append((title,lk,'- ezio - '+str(size)+' GB'+' {Peer: %s / Seed: %s}'%(seed,seed),res))
                       global_var=all_links
    return global_var
        
    