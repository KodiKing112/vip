# -*- coding: utf-8 -*-

import sys,xbmcplugin,xbmcgui,urllib,os,json,logging,cache
from globals import dbcur,Addon,user_dataDir,save_file,win_system#,AWSHandler
def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png",fanart="DefaultFolder.png",description=' '):
 

          
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name),'plot':description   })
          art = {}
          art.update({'poster': iconimage})
          liz.setArt(art)
          liz.setProperty("IsPlayable","false")
          liz.setProperty( "Fanart_Image", fanart )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
          
def addNolink2( name, url,mode,isFolder,fanart='DefaultFolder.png', iconimage="DefaultFolder.png",plot=' ',all_w_trk='',all_w={},heb_name=' ',data=' ',year=' ',generes=' ',rating=' ',trailer=' ',watched='no',original_title=' ',id=' ',season=' ',episode=' ' ,eng_name=' ',show_original_year=' ',dates=' ',dd=' ',dont_place=False):
 
            added_pre=''
            if (episode!=' ' and episode!='%20' and episode!=None) :
             
              tv_show='tv'
            else:
                tv_show='movie'
            if '%' in str(episode):
                episode=' '
            if tv_show=='tv':
                ee=str(episode)
            else:
                ee=str(id)
            time_to_save_trk=int(Addon.getSetting("time_to_save"))
            if all_w_trk!='':
                if float(all_w_trk)>=time_to_save_trk:
                    added_pre='  [COLOR yellow][I]'+'√'+'[/I][/COLOR] \n '
                elif float(all_w_trk)>1:# and float(all_w_trk)<time_to_save_trk:
                    added_pre=' [COLOR yellow][I]'+all_w_trk+'%[/I][/COLOR] \n '
            elif ee in all_w:
                  all_w_time=int((float(all_w[ee]['resume'])*100)/float(all_w[ee]['totaltime']))
                  if float(all_w_time)>=time_to_save_trk:
                        added_pre=' [COLOR yellow][I]'+'√'+'[/I][/COLOR] \n '
                  elif float(all_w_time)>1:# and float(all_w_time)<time_to_save_trk:
                   added_pre=' [COLOR yellow][I]'+str(all_w_time)+'%[/I][/COLOR] \n '            
            params={}
            params['name']=name
            params['iconimage']=iconimage
            params['fanart']=fanart
            params['description']=added_pre+plot.replace("%27","'")
            params['url']=url
            params['data']=data
            params['original_title']=original_title
            params['id']=id
            params['heb_name']=heb_name
            params['season']=season
            params['episode']=episode
            params['eng_name']=original_title
            params['show_original_year']=show_original_year
            params['dates']=dates
            params['dd']=dd
            params['all_w']=json.dumps(all_w)
            menu_items=[]
            
            if mode==146 or mode==15:
                if mode==15:
                    tv_movie='movie'
                else:
                    tv_movie='tv'
                menu_items.append(('[I]%s[/I]'%Addon.getLocalizedString(32161), 'XBMC.RunPlugin(%s)' % ('%s?url=www&original_title=%s&mode=34&name=%s&id=0&season=%s&episode=%s')%(sys.argv[0],original_title,name,season,episode)))
                if len(id)>1:
                    if tv_movie=='tv':
                        tv_mov='tv'
                    else:
                        tv_mov='movie'
                    menu_items.append((Addon.getLocalizedString(32162), 'Action(Queue)' ))
                    menu_items.append((Addon.getLocalizedString(32163), 'XBMC.RunPlugin(%s)' % ('%s?url=%s&mode=150&name=%s&data=%s')%(sys.argv[0],id,original_title,tv_mov) ))
                    menu_items.append(('[I]%s[/I]'%Addon.getLocalizedString(32164), 'XBMC.RunPlugin(%s)' % ('%s?url=www&original_title=add&mode=65&name=%s&id=%s&season=%s&episode=%s')%(sys.argv[0],tv_movie,id,season,episode))) 
                    
                    menu_items.append(('[I]%s[/I]'%Addon.getLocalizedString(32165), 'XBMC.RunPlugin(%s)' % ('%s?url=www&original_title=remove&mode=65&name=%s&id=%s&season=%s&episode=%s')%(sys.argv[0],tv_movie,id,season,episode))) 
                    
                    type_info='extendedtvinfo'
                    if mode==15:
                        type_info='extendedinfo'
                    menu_items.append(('[I]OpenInfo[/I]','RunScript(script.extendedinfo,info=%s,dbid=,id=%s,name=%s,tvshow=%s,season=%s,episode=%s)'%(type_info,id,original_title,original_title,season,episode)))
            if Addon.getSetting("clear_Cache")=='true':
                        menu_items.append(('[I]%s[/I]'%Addon.getLocalizedString(32176), 'XBMC.RunPlugin(%s)' % ('%s?url=www&mode=35')%(sys.argv[0])))
            all_ur=utf8_urlencode(params)
            u=sys.argv[0]+"?&mode="+str(mode)+'&'+all_ur
            
            video_data={}
            video_data['title']=name
            if watched=='yes':
              video_data['playcount']=1
              video_data['overlay']=7
            
            if year!='':
                video_data['year']=year
            if generes!=' ':
                video_data['genre']=generes
            video_data['rating']=str(rating)
        
            #video_data['poster']=fanart
            video_data['plot']=added_pre+plot.replace("%27","'")
            if trailer!='':
                video_data['trailer']=trailer
            
            liz = xbmcgui.ListItem(added_pre.replace('\n','')+ name, iconImage=iconimage, thumbnailImage=iconimage)
            
            '''
            if tv_show=='tv':
                ee=str(episode)
            else:
                ee=str(id)
            if ee in all_w:
            
               liz.setProperty('ResumeTime', all_w[ee]['resume'])
               liz.setProperty('TotalTime', all_w[ee]['totaltime'])
            '''
            liz.setInfo(type="Video", infoLabels=video_data)
            liz.setProperty( "Fanart_Image", fanart )
            liz.setProperty("IsPlayable","false")
            liz.addContextMenuItems(menu_items, replaceItems=False)
            art = {}
            art.update({'poster': iconimage})
            liz.setArt(art)
            if dont_place:
                return u,liz,False
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
          
          
          
          
          
###############################################################################################################        
def get_file_data():
    file_data=[]
    if os.path.exists(save_file):
            f = open(save_file, 'r')
            file_data = f.readlines()
            f.close()
    return file_data
def utf8_urlencode(params):
    import urllib as u
    # problem: u.urlencode(params.items()) is not unicode-safe. Must encode all params strings as utf8 first.
    # UTF-8 encodes all the keys and values in params dictionary
    for k,v in params.items():
        # TRY urllib.unquote_plus(artist.encode('utf-8')).decode('utf-8')
        if type(v) in (int, long, float):
            params[k] = v
        else:
            try:
                params[k.encode('utf-8')] = v.encode('utf-8')
            except Exception as e:
                logging.warning( '**ERROR utf8_urlencode ERROR** %s' % e )
    
    return u.urlencode(params.items()).decode('utf-8')
def addDir3(name,url,mode,iconimage,fanart,description,premired=' ',video_info={},all_w_trk='',all_w={},data=' ',original_title=' ',id=' ',season=' ',episode=' ',tmdbid=' ',eng_name=' ',last_id='',show_original_year=' ',rating=0,heb_name=' ',isr=0,generes=' ',trailer=' ',dates=' ',watched='no',fav_status='false',collect_all=False,ep_number='',watched_ep='',remain='',hist='',dont_place=False):
        
        name=name.replace("|",' ')
        description=description.replace("|",' ')
        params={}
        params['iconimage']=iconimage
        params['fanart']=fanart
        params['description']=description
        params['url']=url
        params['name']=name
        params['heb_name']=heb_name
        params['dates']=dates
        params['data']=data
        params['id']=id
        params['season']=season
        params['episode']=episode
        params['eng_name']=eng_name
        params['isr']=isr
        params['fav_status']=fav_status
        all_ur=utf8_urlencode(params)
        try:
            u=sys.argv[0]+"?mode="+str(mode)+"&name="+(name)+"&heb_name="+(heb_name)+"&dates="+(dates)+"&data="+str(data)+"&original_title="+(original_title)+"&id="+(id)+"&season="+str(season)+"&episode="+str(episode)+"&tmdbid="+str(tmdbid)+"&eng_name="+(eng_name)+"&show_original_year="+(show_original_year)+"&isr="+str(isr)+'&'+all_ur+"&fav_status="+fav_status
        except:
            reload(sys)  
            sys.setdefaultencoding('utf8')
            u=sys.argv[0]+"?mode="+str(mode)+"&name="+(name)+"&heb_name="+(heb_name)+"&dates="+(dates)+"&data="+str(data)+"&original_title="+(original_title)+"&id="+(id)+"&season="+str(season)+"&episode="+str(episode)+"&tmdbid="+str(tmdbid)+"&eng_name="+(eng_name)+"&show_original_year="+(show_original_year)+"&isr="+str(isr)+'&'+all_ur+"&fav_status="+fav_status
        ok=True
        video_data={}
        video_data['title']=name
        video_data['imdbnumber']=id
        video_data['year']=show_original_year
        if (episode!=' ' and episode!='%20' and episode!=None) :
          video_data['mediatype']='episode'
          video_data['TVshowtitle']=original_title
          video_data['Season']=int(str(season).replace('%20','0'))
          video_data['Episode']=int(str(episode).replace('%20','0'))
          
          if premired!=' ':
            video_data['premiered']=premired
          tv_show='tv'

        else:
           video_data['mediatype']='movie'
           video_data['TVshowtitle']=''
           
           # video_data['tvshow']=''
           # video_data['season']=0
           # video_data['episode']=0
           tv_show='movie'
        if  mode==7:
            tv_show='tv'
        video_data['OriginalTitle']=original_title
        if data!=' ':
            video_data['year']=data
        if generes!=' ':
            video_data['genre']=generes
        video_data['rating']=str(rating)
    
        video_data['poster']=fanart
        video_data['plot']=description
        if trailer!=' ':
            video_data['trailer']=trailer
        menu_items=[]

        if watched=='yes':
          video_data['playcount']=1
          video_data['overlay']=7

        str_e1=list(u.encode('utf8'))
        for i in range(0,len(str_e1)):
           str_e1[i]=str(ord(str_e1[i]))
        str_e='$$'.join(str_e1)
        
        change=0
        file_data=cache.get(get_file_data,9999, table='save_file')
        
        dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s'"%(original_title.replace("'"," ").replace(" ","%20").replace(':','%3a').replace("'",'%27')))

        match = dbcur.fetchone()
       
        if match!=None:
        
          menu_items.append(('הסר ממעקב סדרות', 'XBMC.RunPlugin(%s)' % ('%s?url=www&original_title=%s&mode=34&name=%s&id=0&season=%s&episode=%s')%(sys.argv[0],original_title,name,season,episode)))
        dbcur.execute("SELECT * FROM AllData WHERE original_title = '%s'  AND season='%s' AND episode = '%s'"%(original_title.replace("'"," ").replace(" ","%20").replace(':','%3a').replace("'",'%27'),season,episode))
     
        match = dbcur.fetchone()
        if match!=None:
          
          menu_items.append(('הסר סימון נצפה', 'XBMC.RunPlugin(%s)' % ('%s?url=www&original_title=%s&mode=34&name=%s&id=1&season=%s&episode=%s')%(sys.argv[0],original_title,name,season,episode))) 
        if str_e+'\n' not in file_data:
           menu_items.append(('ניקוי מטמון', 'XBMC.RunPlugin(%s)' % ('%s?url=www&description=%s&mode=16')%(sys.argv[0],str_e)))
          
        if str_e+'\n' not in file_data:
           menu_items.append(('הוספה למועדפים שלי', 'XBMC.RunPlugin(%s)' % ('%s?url=www&description=%s&mode=17')%(sys.argv[0],str_e)))
           
        else:
           
           menu_items.append(('הסרה מהמועדפים שלי', 'XBMC.RunPlugin(%s)' % ('%s?url=www&description=%s&mode=19')%(sys.argv[0],str_e)))
        if mode==7:
            menu_items.append(('פתח פרק אחרון ששודר', 'XBMC.RunPlugin(%s)' % ('%s?url=www&mode=109&id=%s')%(sys.argv[0],id)))
        if Addon.getSetting("use_trak")=='true' and len(id)>1:
            
            
              
              menu_items.append(('נצפה בטראק', 'XBMC.RunPlugin(%s)' % ('%s?url=www&original_title=add&mode=65&name=%s&id=%s&season=%s&episode=%s')%(sys.argv[0],tv_show,id,season,episode))) 
            
              menu_items.append(('לא נצפה בטראק', 'XBMC.RunPlugin(%s)' % ('%s?url=www&original_title=remove&mode=65&name=%s&id=%s&season=%s&episode=%s')%(sys.argv[0],tv_show,id,season,episode))) 
        if mode==4 and hist=='true':
            menu_items.append(('הסר מאיפה הייתי', 'XBMC.RunPlugin(%s)' % ('%s?url=%s&mode=159&name=%s&id=%s&season=%s&episode=%s')%(sys.argv[0],tv_show,name.replace("'",'%27').replace(",",'%28'),id,season,episode))) 
            
        if mode==3 and '%s' not in url:
            menu_items.append(('מחק מההיסטוריה', 'XBMC.RunPlugin(%s)' % ('%s?url=%s&mode=152&name=%s')%(sys.argv[0],tv_show,name))) 
        
        if (mode==4 or mode==7) :
            menu_items.append(('משהו דומה..', 'Container.update(%s)' % ('%s?url=%s&mode=26&id=%s')%(sys.argv[0],tv_show,id))) 
        if (mode==4 or mode==3) and 'movie' in url:
            menu_items.append(('בדוק תאריך יציאה באיכות', 'XBMC.RunPlugin(%s)' % ('%s?url=%s&mode=153&name=%s&data=%s&id=%s')%(sys.argv[0],tv_show,original_title,data,id))) 
        menu_items.append(('פרטים', 'Action(Info)'))
        menu_items.append(('%s'%'הגדרות הרחבה', 'RunPlugin(%s?mode=24&url=www)' % sys.argv[0] ))
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.addContextMenuItems(menu_items, replaceItems=False)
        if video_info!={}:
            
            video_data=video_info
      
        # if 'fast' not in video_info and id!=' ':
        info = {'title': id, 'season': season, 'episode': episode}
        dbcur.execute("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(id,str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
        
        match_playtime = dbcur.fetchone()
        
        if match_playtime!=None:
   
            name_r,timdb_r,season_r,episode_r,playtime,totaltime,free=match_playtime
            res={}
            #logging.warning((float(totaltime)*0.95))
            
            if (float(totaltime)*0.95)<=float(playtime):
                res['wflag']=True
            else:
            
                res['wflag']=False
            res['resumetime']=playtime
            res['totaltime']=totaltime
        else:
            res=False
           
            
            #res = AWSHandler.CheckWS(info)
            if res:
                if res['wflag']:
                    #listitem.setInfo(type = 'video', infoLabels = {'playcount': 1, 'overlay': 5})
                    video_data['playcount']=1
                    video_data['overlay']=5
            if res:
                if not res['wflag']:
                  if res['resumetime']!=None:
                    
                    video_data['playcount']=0
                    video_data['overlay']=0
                    liz.setProperty('ResumeTime', res['resumetime'])
                    liz.setProperty('TotalTime', res['totaltime'])
        liz.setProperty( "Fanart_Image", fanart )
        if ep_number!='':
            logging.warning('ep_number:'+str(ep_number))
            liz.setProperty('totalepisodes', str(ep_number))
        if watched_ep!='':
           logging.warning('watched_ep:'+ str(watched))
           liz.setProperty('watchedepisodes', str(watched))
                
        
        if remain!='':
            logging.warning('remain:'+ str(remain))
            liz.setProperty('unwatchedepisodes',str(remain))
        art = {}
        art.update({'poster': iconimage})
        liz.setArt(art)
        video_data['title']=video_data['title'].replace("|",' ')
        video_data['plot']=video_data['plot'].replace("|",' ')
  
        
        if (mode==4 ) and Addon.getSetting("new_source_menu")=='true' and  Addon.getSetting("new_window_type2")!='3' and  Addon.getSetting("new_window_type2")!='4':
            liz.setProperty("IsPlayable","true")
            isfolder=False
            video_data['title']=name
        else:
            isfolder=True
        
        if (mode==4 ) and Addon.getSetting("new_source_menu")=='true' and (Addon.getSetting("new_window_type2")=='3' or  Addon.getSetting("new_window_type2")=='4') and  Addon.getSetting("show_sources_in_4")=='false':
            
        
        
            
            isfolder=False
            liz.setProperty("IsPlayable","true")
            
        if len(id)>1:
            
            tt='Video'
        else:
            tt='Files'
        liz.setInfo( type=tt, infoLabels=video_data)
        if collect_all:
            return u,liz,isfolder
        
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isfolder)
        
        return ok,liz



def addLink( name, url,mode,isFolder, iconimage,fanart,description,video_info={},isr=' ',data='',original_title=' ',id=' ',season=' ',episode=' ',rating=0,saved_name=' ',prev_name=' ',eng_name=' ',heb_name=' ',show_original_year=' ',generes=' ',num_in_list=None,dont_earse=False,collect_all=False,shortcut=False,trailer=' ',kids_movies=False):
          #url=url.encode('utf8')

          name=name.replace("|",' ')
          description=description.replace("|",' ')
          if shortcut:
            description=description+'\nshortshortcut'
          try:
            name=urllib.unquote(name)
          except:
            pass
          name=name.replace("openload","vumoo").replace("Openload","vumoo").replace('letsupload','avlts')
          
          description=description.replace("openload","vumoo").replace("Openload","vumoo").replace('letsupload','avlts')
          name=name.replace("thevideo","tvumoo.li")
          description=description.replace("thevideo","tvumoo.li")
          
          te1=sys.argv[0]+"?url="+urllib.quote_plus(url.encode('utf8'))+"&mode="+str(mode)
          te2="&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage.encode('utf8'))+"&fanart="+urllib.quote_plus(fanart.encode('utf8'))+"&description="+(description)+"&heb_name="+(heb_name)
          te3="&data="+str(data)+"&original_title="+(original_title)+"&id="+(id)+"&season="+str(season)
          te4="&episode="+str(episode)+"&isr="+str(isr)
        
          try:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url.encode('utf8'))+"&mode="+str(mode)+"&name="+(name)+"&data="+str(data)+"&iconimage="+urllib.quote_plus(iconimage.encode('utf8'))+"&fanart="+urllib.quote_plus(fanart.encode('utf8'))+"&description="+(description)+"&original_title="+(original_title)+"&id="+str(id)+"&season="+str(season)+"&episode="+str(episode)+"&saved_name="+str(saved_name)+"&prev_name="+str(prev_name)+"&eng_name="+str(eng_name)+"&heb_name="+(heb_name)+"&show_original_year="+str(show_original_year)
          except:
              params={}
              params['name']=name
              params['iconimage']=iconimage
              params['fanart']=fanart
              params['description']=description
              params['url']=url
              # params['no_subs']=no_subs
              params['season']=season
              params['episode']=episode
              params['mode']=mode
              params['original_title']=original_title
              # params['id']=tmdb
              # params['dd']=dd
              params['data']=data
              # params['nextup']='false'
              
              all_ur=utf8_urlencode(params)
              u=sys.argv[0]+"?"+'&'+all_ur
          info = {'title': id, 'season': season, 'episode': episode}
          #res = AWSHandler.CheckWS(info)
          
          menu_items=[]
          
          
          video_data={}
          video_data['title']=name
          video_data['season']=season
          video_data['episode']=episode
          video_data['poster']=fanart
          video_data['plot']=description
          video_data['genre']=generes
          video_data['year']=show_original_year
          if rating!=0:
            video_data['rating']=str(rating)
            
            
          #video_data['playcount']=1
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)
          res=False
          if kids_movies:
          #if 0:
            
            if id=='%20' or len(id)<2:
                check_id=original_title
            else:
                check_id=id
            dbcur.execute("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(check_id,str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
            
            match_playtime = dbcur.fetchone()
            
            if match_playtime!=None:
       
                name_r,timdb_r,season_r,episode_r,playtime,totaltime,free=match_playtime
                res={}
                #logging.warning((float(totaltime)*0.95))
                
                if (float(totaltime)*0.95)<=float(playtime):
                    res['wflag']=True
                else:
                
                    res['wflag']=False
                
                res['resumetime']=playtime
                res['totaltime']=totaltime
            else:
                res=False
           
            
            #res = AWSHandler.CheckWS(info)
            if res:
                if res['wflag']:
                    #listitem.setInfo(type = 'video', infoLabels = {'playcount': 1, 'overlay': 5})
                    video_data['playcount']=1
                    video_data['overlay']=5
            if res:
                if not res['wflag']:
                  if res['resumetime']!=None:
                    
                    video_data['playcount']=0
                    video_data['overlay']=0
                    liz.setProperty('ResumeTime', res['resumetime'])
                    liz.setProperty('TotalTime', res['totaltime'])
            
          
          #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          
          if video_info!={}:
            #if type(video_data) is dict:
            #  video_data=video_info
            #else:
            video_data=json.loads(video_info)
            if '-HebDub-shortshortcut' in description:
                video_data['plot']=video_data['plot']+'-HebDub-shortshortcut'
          if res:
                if res['wflag']:
                    #listitem.setInfo(type = 'video', infoLabels = {'playcount': 1, 'overlay': 5})
                    video_data['playcount']=1
                    video_data['overlay']=5
          if res:
            if not res['wflag']:
              if res['resumetime']!=None:
                
                video_data['playcount']=0
                video_data['overlay']=0
                liz.setProperty('ResumeTime', res['resumetime'])
                liz.setProperty('TotalTime', res['totaltime'])
          video_data['title']=video_data['title'].replace("|",' ')
          video_data['plot']=video_data['plot'].replace("|",' ')
          if trailer!=' ':
            video_data['trailer']=trailer
          liz.setInfo(type="Video", infoLabels=video_data)
        
          art = {}
          art.update({'poster': iconimage})
          liz.setArt(art)
          if shortcut or  'TEME' in description :
            liz.setProperty("IsPlayable","false")
          else:
            liz.setProperty("IsPlayable","true")
          liz.setProperty( "Fanart_Image", fanart )

          if 0:
            if not res['wflag']:
           
                liz.setProperty('ResumeTime', '0')
                liz.setProperty('TotalTime', '1')
          if dont_earse==False:
              liz.setProperty('ResumeTime', '0')
              liz.setProperty('TotalTime','1')
          if num_in_list=='remove':
             menu_items.append(('מחק ערוץ שלי', 'XBMC.RunPlugin(%s)' % ('%s?url=www&name=%s&mode=96')%(sys.argv[0],name)))
          elif num_in_list!=None:
             menu_items.append(('[I]הסרה מהמועדפים שלי[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&description=%s&mode=20')%(sys.argv[0],num_in_list)))
          if win_system:
            menu_items.append(('[I]הורד באמצעות IDM[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=%s&mode=67')%(sys.argv[0],url)))
          if '127.0.0.1:6878' in url:
             menu_items.append(('הוסף לאייסטרים שלי', 'XBMC.RunPlugin(%s)' % ('%s?url=%s&description=add&name=%s&mode=78')%(sys.argv[0],urllib.quote_plus(url),name)))
             menu_items.append(('הסר מהאייסטרים שלי', 'XBMC.RunPlugin(%s)' % ('%s?url=%s&description=remove&name=%s&mode=78')%(sys.argv[0],urllib.quote_plus(url),name)))
          liz.addContextMenuItems(menu_items, replaceItems=False)
          
           
          if collect_all:
            return u,liz,isFolder
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)

          